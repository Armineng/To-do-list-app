import 'package:flutter/material.dart';

Color customGreen = Color(0xff18DAA3);

// Function to get background color based on theme
Color getBackgroundColor(BuildContext context) {
  return Theme.of(context).scaffoldBackgroundColor;
}

// Function to get card color based on theme
Color getCardColor(BuildContext context) {
  return Theme.of(context).cardTheme.color ?? Colors.white;
}

// Function to get text color based on theme
Color getTextColor(BuildContext context) {
  return Theme.of(context).textTheme.bodyLarge?.color ?? Colors.black;
}

// Function to get border color based on theme
Color getBorderColor(BuildContext context) {
  return Theme.of(context).brightness == Brightness.dark
      ? Colors.grey.shade700
      : Color(0xffc5c5c5);
}
