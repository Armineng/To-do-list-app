import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:to_do_list/const/colors.dart';
import 'package:to_do_list/model/category_model.dart';
import 'package:to_do_list/widgets/task_widgets.dart';

import '../data/firestor.dart';

class Stream_note extends StatefulWidget {
  final bool done;
  final String? categoryId;

  Stream_note(this.done, {this.categoryId, Key? key}) : super(key: key);

  @override
  State<Stream_note> createState() => _Stream_noteState();
}

class _Stream_noteState extends State<Stream_note> {
  final Firestore_Datasource _firestoreDataSource = Firestore_Datasource();
  String? selectedCategoryId;

  @override
  void initState() {
    super.initState();
    selectedCategoryId = widget.categoryId;
  }

  @override
  Widget build(BuildContext context) {
    // Get the text color based on the current theme
    final textColor = getTextColor(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Column(
      children: [
        // Category filter dropdown
        if (!widget.done) // Only show category filter for active tasks
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 15),
              decoration: BoxDecoration(
                color: getCardColor(context),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: getBorderColor(context)),
              ),
              child: StreamBuilder<QuerySnapshot>(
                stream: _firestoreDataSource.categoriesStream(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }

                  final categories =
                      _firestoreDataSource.getCategories(snapshot);

                  return Theme(
                    // Apply a local theme override for the dropdown
                    data: Theme.of(context).copyWith(
                      // Set the popup menu background color
                      canvasColor: getCardColor(context),
                      // Override dropdown styles
                      popupMenuTheme: PopupMenuThemeData(
                        color: getCardColor(context),
                      ),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        isExpanded: true,
                        hint: Text('Filter by category',
                            style: TextStyle(color: textColor)),
                        value: selectedCategoryId,
                        icon: Icon(Icons.arrow_drop_down, color: customGreen),
                        dropdownColor: getCardColor(context),
                        onChanged: (value) {
                          setState(() {
                            selectedCategoryId = value;
                          });
                        },
                        items: [
                          DropdownMenuItem<String>(
                            value: null,
                            child: Text('All categories',
                                style: TextStyle(color: textColor)),
                          ),
                          ...categories.map((category) {
                            return DropdownMenuItem<String>(
                              value: category.id,
                              child: Row(
                                children: [
                                  Container(
                                    width: 16,
                                    height: 16,
                                    decoration: BoxDecoration(
                                      color: Color(category.colorValue),
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                  SizedBox(width: 8),
                                  Text(
                                    category.name,
                                    style: TextStyle(color: textColor),
                                  ),
                                ],
                              ),
                            );
                          }).toList(),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),

        // Tasks list
        StreamBuilder<QuerySnapshot>(
            stream: _firestoreDataSource.stream(widget.done,
                categoryId: selectedCategoryId),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(child: CircularProgressIndicator());
              }

              if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                return Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Center(
                    child: Text(
                      selectedCategoryId != null
                          ? 'No tasks found in this category'
                          : 'No tasks found',
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                );
              }

              final notesList = _firestoreDataSource.getNotes(snapshot);
              return ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemBuilder: (context, index) {
                  final note = notesList[index];
                  return Dismissible(
                    key: UniqueKey(),
                    onDismissed: (direction) {
                      _firestoreDataSource.delet_note(note.id);
                    },
                    child: Task_Widget(note),
                  );
                },
                itemCount: notesList.length,
              );
            }),
      ],
    );
  }
}
