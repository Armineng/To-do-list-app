class Category {
  String id;
  String name;
  int colorValue; // Stores color as an integer value

  Category(this.id, this.name, this.colorValue);

  // Convert to a map for Firestore
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'colorValue': colorValue,
    };
  }

  // Create a Category from a Firestore document
  factory Category.fromMap(Map<String, dynamic> map) {
    return Category(
      map['id'],
      map['name'],
      map['colorValue'],
    );
  }
}
