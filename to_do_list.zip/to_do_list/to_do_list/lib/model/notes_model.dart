class Note {
  String id;
  String subtitle;
  String title;
  String time;
  int image;
  bool isDon;
  String? categoryId;

  Note(this.id, this.subtitle, this.time, this.image, this.title, this.isDon,
      {this.categoryId});

  // Convert to a map for Firestore
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'subtitle': subtitle,
      'title': title,
      'time': time,
      'image': image,
      'isDon': isDon,
      'categoryId': categoryId,
    };
  }

  // Create a Note from a Firestore document
  factory Note.fromMap(Map<String, dynamic> map) {
    return Note(
      map['id'],
      map['subtitle'],
      map['time'],
      map['image'],
      map['title'],
      map['isDon'],
      categoryId: map['categoryId'],
    );
  }
}
