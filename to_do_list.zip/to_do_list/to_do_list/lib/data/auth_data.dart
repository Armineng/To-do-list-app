import 'package:firebase_auth/firebase_auth.dart';
import 'package:to_do_list/data/firestor.dart';

abstract class AuthenticationDatasource {
  Future<void> register(String email, String password, String PasswordConfirm);
  Future<void> login(String email, String password);
}

class AuthenticationRemote extends AuthenticationDatasource {
  @override
  Future<void> login(String email, String password) async {
    try {
      print("Login attempt: ${email.trim()}");
      UserCredential result = await FirebaseAuth.instance
          .signInWithEmailAndPassword(
              email: email.trim(), password: password.trim());
      print("Login successful: ${result.user?.uid}");

      // Ensure the auth state has been updated
      User? currentUser = FirebaseAuth.instance.currentUser;
      print("Current user after login: ${currentUser?.uid}");

      // Force refresh the token
      if (currentUser != null) {
        await currentUser.reload();
        print("User reloaded");
      }
    } catch (e) {
      print("Authentication error: $e");
      // Rethrow to let the UI handle specific error types
      rethrow;
    }
  }

  @override
  Future<void> register(
      String email, String password, String PasswordConfirm) async {
    if (PasswordConfirm != password) {
      throw FirebaseAuthException(
        code: 'passwords-dont-match',
        message: 'Passwords do not match',
      );
    }

    // Let Firebase handle the email-already-in-use error
    await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: email.trim(), password: password.trim());

    // Only create user after successful registration
    await Firestore_Datasource().CreateUser(email);
  }
}
