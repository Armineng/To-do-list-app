import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:to_do_list/auth/auth_page.dart';
import 'package:to_do_list/screen/home.dart';

class MainPage extends StatelessWidget {
  const MainPage({super.key});

  @override
  Widget build(BuildContext context) {
    print("Building MainPage");

    // Add a listener to debug auth state changes
    FirebaseAuth.instance.authStateChanges().listen((User? user) {
      print(
          "Auth state changed: User is ${user != null ? 'signed in' : 'signed out'}");
      if (user != null) {
        print("User ID: ${user.uid}, Email: ${user.email}");
      }
    });

    return Scaffold(
      body: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          print(
              "StreamBuilder update: hasData=${snapshot.hasData}, connectionState=${snapshot.connectionState}");

          if (snapshot.hasData) {
            print("Navigating to Home_Screen");
            return Home_Screen();
          } else {
            print("Navigating to Auth_Page");
            return Auth_Page();
          }
        },
      ),
    );
  }
}
