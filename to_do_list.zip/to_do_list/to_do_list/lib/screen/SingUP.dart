import 'package:flutter/material.dart';
import 'package:to_do_list/const/colors.dart';
import 'package:to_do_list/data/auth_data.dart';
import 'package:firebase_auth/firebase_auth.dart';

class SignUp_Screen extends StatefulWidget {
  final VoidCallback show;
  SignUp_Screen(this.show, {super.key});

  @override
  State<SignUp_Screen> createState() => _SignUp_ScreenState();
}

class _SignUp_ScreenState extends State<SignUp_Screen> {
  FocusNode _focusNode1 = FocusNode();
  FocusNode _focusNode2 = FocusNode();
  FocusNode _focusNode3 = FocusNode();

  final email = TextEditingController();
  final password = TextEditingController();
  final PasswordConfirm = TextEditingController();
  bool _isPassword1Visible = false;
  bool _isPassword2Visible = false;
  String? _passwordError;
  String? _confirmPasswordError;
  String? _emailError;
  bool _isSigningUp = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _focusNode1.addListener(() {
      setState(() {});
    });
    _focusNode2.addListener(() {
      setState(() {});
    });
    _focusNode3.addListener(() {
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: getBackgroundColor(context),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 20),
              image(),
              SizedBox(height: 50),
              textfield(email, _focusNode1, 'Email', Icons.email),
              if (_emailError != null)
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      _emailError!,
                      style: TextStyle(color: Colors.red, fontSize: 12),
                    ),
                  ),
                ),
              SizedBox(height: 10),
              passwordField(
                  password,
                  _focusNode2,
                  'Password',
                  _isPassword1Visible,
                  (value) => setState(() => _isPassword1Visible = value)),
              if (_passwordError != null)
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      _passwordError!,
                      style: TextStyle(color: Colors.red, fontSize: 12),
                    ),
                  ),
                ),
              SizedBox(height: 10),
              passwordField(
                  PasswordConfirm,
                  _focusNode3,
                  'Confirm Password',
                  _isPassword2Visible,
                  (value) => setState(() => _isPassword2Visible = value)),
              if (_confirmPasswordError != null)
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      _confirmPasswordError!,
                      style: TextStyle(color: Colors.red, fontSize: 12),
                    ),
                  ),
                ),
              SizedBox(height: 8),
              account(),
              SizedBox(height: 20),
              SignUP_bottom(),
            ],
          ),
        ),
      ),
    );
  }

  Widget account() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Text(
            "Do you have an account?",
            style: TextStyle(color: Colors.grey[700], fontSize: 14),
          ),
          SizedBox(width: 5),
          GestureDetector(
            onTap: widget.show,
            child: Text(
              'Login',
              style: TextStyle(
                  color: Colors.blue,
                  fontSize: 14,
                  fontWeight: FontWeight.bold),
            ),
          )
        ],
      ),
    );
  }

  Widget SignUP_bottom() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: InkWell(
        onTap: _isSigningUp
            ? null
            : () {
                if (validateInputs()) {
                  _signUp();
                }
              },
        child: AnimatedContainer(
          duration: Duration(milliseconds: 200),
          alignment: Alignment.center,
          width: double.infinity,
          height: 50,
          decoration: BoxDecoration(
            color: _isSigningUp ? customGreen.withOpacity(0.7) : customGreen,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 4,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: _isSigningUp
              ? SizedBox(
                  height: 24,
                  width: 24,
                  child: CircularProgressIndicator(
                    color: Colors.white,
                    strokeWidth: 2.0,
                  ),
                )
              : Text(
                  'Sign Up',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 23,
                    fontWeight: FontWeight.bold,
                  ),
                ),
        ),
      ),
    );
  }

  void _signUp() async {
    if (!mounted) return;

    setState(() {
      _isSigningUp = true;
      // Clear any previous errors
      _emailError = null;
      _passwordError = null;
      _confirmPasswordError = null;
    });

    try {
      await AuthenticationRemote()
          .register(email.text, password.text, PasswordConfirm.text);
      // Registration successful - Stream in MainPage will handle navigation
    } catch (e) {
      print("Signup error: ${e.toString()}");

      if (!mounted)
        return; // Check if widget is still mounted before updating state

      if (e is FirebaseAuthException) {
        // Handle specific Firebase Auth errors
        switch (e.code) {
          case 'email-already-in-use':
            setState(() {
              _emailError = "This email is already registered";
            });
            break;
          case 'invalid-email':
            setState(() {
              _emailError = "Invalid email format";
            });
            break;
          case 'weak-password':
            setState(() {
              _passwordError = "Password is too weak (min 6 characters)";
            });
            break;
          case 'passwords-dont-match':
            setState(() {
              _confirmPasswordError = "Passwords do not match";
            });
            break;
          default:
            if (mounted) {
              // Check if still mounted before showing snackbar
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Error: ${e.message}')),
              );
            }
            break;
        }
      } else {
        // Handle generic errors
        if (mounted) {
          // Check if still mounted before showing snackbar
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Registration failed: ${e.toString()}')),
          );
        }
      }
    } finally {
      if (mounted) {
        // Check if widget is still mounted before updating state
        setState(() {
          _isSigningUp = false;
        });
      }
    }
  }

  bool validateInputs() {
    if (!mounted) return false;

    // Clear existing errors
    setState(() {
      _passwordError = null;
      _confirmPasswordError = null;
      _emailError = null;
    });

    bool isValid = true;

    // Email validation
    if (email.text.trim().isEmpty) {
      if (!mounted) return false;
      setState(() {
        _emailError = 'Please enter an email';
      });
      isValid = false;
    } else if (!email.text.contains('@') || !email.text.contains('.')) {
      if (!mounted) return false;
      setState(() {
        _emailError = 'Please enter a valid email';
      });
      isValid = false;
    }

    // Create separate error messages for each password field
    String? passwordErrorText;
    String? confirmPasswordErrorText;

    // Validate main password
    if (password.text.isEmpty) {
      passwordErrorText = 'Please enter a password';
      isValid = false;
    } else if (password.text.length < 6) {
      passwordErrorText = 'Password must be at least 6 characters';
      isValid = false;
    }

    // Validate confirm password
    if (PasswordConfirm.text.isEmpty) {
      confirmPasswordErrorText = 'Please confirm your password';
      isValid = false;
    } else if (password.text != PasswordConfirm.text) {
      confirmPasswordErrorText = 'Passwords do not match';
      isValid = false;
    }

    // Update the UI with error messages if needed
    if (passwordErrorText != null || confirmPasswordErrorText != null) {
      if (!mounted) return false;
      setState(() {
        // Show the most important error message
        if (passwordErrorText != null) {
          _passwordError = passwordErrorText;
        }
        if (confirmPasswordErrorText != null) {
          _confirmPasswordError = confirmPasswordErrorText;
        }
      });
    }

    return isValid;
  }

  Widget textfield(TextEditingController _controller, FocusNode _focusNode,
      String typeName, IconData iconss) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Container(
        decoration: BoxDecoration(
          color: getCardColor(context),
          borderRadius: BorderRadius.circular(15),
        ),
        child: TextField(
          controller: _controller,
          focusNode: _focusNode,
          style: TextStyle(fontSize: 18),
          decoration: InputDecoration(
              prefixIcon: Icon(
                iconss,
                color: _focusNode.hasFocus ? customGreen : Color(0xffc5c5c5),
              ),
              contentPadding:
                  EdgeInsets.symmetric(horizontal: 15, vertical: 15),
              hintText: typeName,
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(
                  color: getBorderColor(context),
                  width: 2.0,
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(
                  color: customGreen,
                  width: 2.0,
                ),
              )),
        ),
      ),
    );
  }

  Widget passwordField(TextEditingController controller, FocusNode focusNode,
      String hintText, bool isVisible, Function(bool) onVisibilityChanged) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Container(
        decoration: BoxDecoration(
          color: getCardColor(context),
          borderRadius: BorderRadius.circular(15),
        ),
        child: TextField(
          controller: controller,
          focusNode: focusNode,
          obscureText: !isVisible,
          style: TextStyle(fontSize: 18),
          decoration: InputDecoration(
            prefixIcon: Icon(
              Icons.password,
              color: focusNode.hasFocus ? customGreen : Color(0xffc5c5c5),
            ),
            suffixIcon: IconButton(
              icon: Icon(
                isVisible ? Icons.visibility_off : Icons.visibility,
                color: focusNode.hasFocus ? customGreen : Color(0xffc5c5c5),
              ),
              onPressed: () {
                onVisibilityChanged(!isVisible);
              },
            ),
            contentPadding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
            hintText: hintText,
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(
                color: getBorderColor(context),
                width: 2.0,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(
                color: customGreen,
                width: 2.0,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget image() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Container(
        width: double.infinity,
        height: 300,
        decoration: BoxDecoration(
          color: getBackgroundColor(context),
          image: DecorationImage(
            image: AssetImage('images/7.png'),
            fit: BoxFit.fitWidth,
          ),
        ),
      ),
    );
  }
}
