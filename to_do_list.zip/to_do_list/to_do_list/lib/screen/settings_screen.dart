import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:to_do_list/const/colors.dart';
import 'package:to_do_list/const/theme_provider.dart';
import 'package:to_do_list/auth/auth_page.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  // Hard-coded app information
  final String appVersion = '1.0.0';
  final String appName = 'To-Do List';
  final String appDeveloper = 'Your Name';
  final String appReleaseYear = '2025';

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: getBackgroundColor(context),
      appBar: AppBar(
        title: Text(
          'Settings',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Column(
        children: [
          // Main content in scrollable area
          Expanded(
            child: ListView(
              padding: EdgeInsets.all(16),
              children: [
                // Account Section
                _buildSectionHeader(context, 'Account'),
                Card(
                  elevation: 0,
                  color: getCardColor(context),
                  margin: EdgeInsets.symmetric(vertical: 4),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Icon(Icons.account_circle_outlined, color: customGreen),
                        SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Email',
                                style: TextStyle(
                                  fontSize: 16,
                                ),
                              ),
                              SizedBox(height: 4),
                              Text(
                                FirebaseAuth.instance.currentUser?.email ??
                                    'Not signed in',
                                style: TextStyle(
                                  color: Theme.of(context)
                                      .textTheme
                                      .bodySmall
                                      ?.color,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                _buildSettingItem(
                  context,
                  icon: Icons.password,
                  title: 'Change Password',
                  subtitle: 'Update your account password',
                  onTap: () {
                    _showPasswordResetDialog(context);
                  },
                ),
                Divider(height: 32),

                // Appearance Section
                _buildSectionHeader(context, 'Appearance'),
                _buildSwitchItem(
                  context,
                  icon: themeProvider.isDarkMode
                      ? Icons.dark_mode
                      : Icons.light_mode,
                  title: 'Dark Mode',
                  subtitle: 'Switch between light and dark themes',
                  value: themeProvider.isDarkMode,
                  onChanged: (value) {
                    themeProvider.toggleTheme();
                  },
                ),
                Divider(height: 32),

                // Info Section
                _buildSectionHeader(context, 'App Information'),
                _buildSettingItem(
                  context,
                  icon: Icons.info_outline,
                  title: 'Version',
                  subtitle: appVersion,
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text('Current version: $appVersion')));
                  },
                ),
                _buildSettingItem(
                  context,
                  icon: Icons.code,
                  title: 'About',
                  subtitle: 'Learn more about this app',
                  onTap: () {
                    _showAboutDialog(context);
                  },
                ),
                _buildSettingItem(
                  context,
                  icon: Icons.help_outline,
                  title: 'Help & Support',
                  subtitle: 'Get assistance with the app',
                  onTap: () {
                    _showHelpDialog(context);
                  },
                ),

                // Logout button at the bottom of the scrollable content
                Container(
                  padding: EdgeInsets.all(16),
                  alignment: Alignment.center,
                  child: ElevatedButton(
                    onPressed: () => _logoutAndNavigateToLogin(context),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                      minimumSize: Size(150, 50),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: Text(
                      'Logout',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: customGreen,
        ),
      ),
    );
  }

  Widget _buildSettingItem(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 0,
      color: getCardColor(context),
      margin: EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        leading: Icon(icon, color: customGreen),
        title: Text(title),
        subtitle: Text(subtitle),
        trailing: Icon(Icons.arrow_forward_ios, size: 16),
        onTap: onTap,
      ),
    );
  }

  Widget _buildSwitchItem(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Card(
      elevation: 0,
      color: getCardColor(context),
      margin: EdgeInsets.symmetric(vertical: 4),
      child: SwitchListTile(
        secondary: Icon(icon, color: customGreen),
        title: Text(title),
        subtitle: Text(subtitle),
        value: value,
        activeColor: customGreen,
        onChanged: onChanged,
      ),
    );
  }

  void _showLogoutConfirmation(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Logout'),
        content: Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              _logoutAndNavigateToLogin(context);
            },
            child: Text('Logout', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _logoutAndNavigateToLogin(BuildContext context) {
    FirebaseAuth.instance.signOut();
    // Navigate to login screen, removing all previous routes
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (context) => Auth_Page()),
      (route) => false,
    );
  }

  void _showAboutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('About $appName'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset('images/0.png', width: 50, height: 50),
            SizedBox(height: 16),
            Text(appName,
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            Text('Version: $appVersion'),
            SizedBox(height: 16),
            Text(
              'A modern and feature-rich to-do list application built with Flutter and Firebase, designed to help you manage your tasks efficiently.',
              style: TextStyle(fontSize: 14),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 12),
            Text('Developed by: Armin&Zanon',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
            SizedBox(height: 8),
            Text('© $appReleaseYear $appName',
                style: TextStyle(fontSize: 12, color: Colors.grey)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showPasswordResetDialog(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null || user.email == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('You need to be logged in to reset your password')));
      return;
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Reset Password'),
        content: Text('We will send a password reset email to ${user.email}'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              try {
                await FirebaseAuth.instance
                    .sendPasswordResetEmail(email: user.email!);
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Password reset email sent')));
              } catch (e) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text(
                        'Error sending password reset email: ${e.toString()}')));
              }
            },
            child: Text('Send Email'),
          ),
        ],
      ),
    );
  }

  void _showHelpDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Help & Support'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Need help with the app?'),
            SizedBox(height: 16),
            Text('Contact us:'),
            SizedBox(height: 8),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.grey[800]
                    : Colors.grey[200],
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.email, size: 18, color: customGreen),
                  SizedBox(width: 8),
                  SelectableText(
                    'arminmalamin2@gmail.com',
                    style: TextStyle(
                      fontWeight: FontWeight.w500,
                      letterSpacing: 0.3,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }
}
