import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:to_do_list/const/colors.dart';
import 'package:to_do_list/data/firestor.dart';
import 'package:to_do_list/model/category_model.dart';

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({Key? key}) : super(key: key);

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  final Firestore_Datasource _firestoreDataSource = Firestore_Datasource();
  final TextEditingController _categoryNameController = TextEditingController();
  Color _currentColor = Colors.blue;

  @override
  void dispose() {
    _categoryNameController.dispose();
    super.dispose();
  }

  void _showCategoryDialog({Category? category}) {
    if (category != null) {
      _categoryNameController.text = category.name;
      _currentColor = Color(category.colorValue);
    } else {
      _categoryNameController.clear();
      _currentColor = Colors.blue;
    }

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(category == null ? 'Add Category' : 'Edit Category'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: _categoryNameController,
                  decoration: InputDecoration(
                    labelText: 'Category Name',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 20),
                Text('Category Color'),
                SizedBox(height: 10),
                BlockPicker(
                  pickerColor: _currentColor,
                  onColorChanged: (color) {
                    setState(() {
                      _currentColor = color;
                    });
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                final name = _categoryNameController.text.trim();
                if (name.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Please enter a category name')),
                  );
                  return;
                }

                if (category == null) {
                  // Add new category
                  await _firestoreDataSource.addCategory(
                    name,
                    _currentColor.value,
                  );
                } else {
                  // Update existing category
                  await _firestoreDataSource.updateCategory(
                    category.id,
                    name,
                    _currentColor.value,
                  );
                }

                Navigator.of(context).pop();
              },
              child: Text(category == null ? 'Add' : 'Save'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: getBackgroundColor(context),
      appBar: AppBar(
        title: Text(
          'Categories',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: getBackgroundColor(context),
        elevation: 0,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _firestoreDataSource.categoriesStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          final categories = _firestoreDataSource.getCategories(snapshot);

          if (categories.isEmpty) {
            return Center(
              child: Text(
                'No categories yet. Add your first category!',
                style: TextStyle(fontSize: 16),
              ),
            );
          }

          return ListView.builder(
            itemCount: categories.length,
            itemBuilder: (context, index) {
              final category = categories[index];
              return Card(
                elevation: 1,
                margin: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                color: getCardColor(context),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Color(category.colorValue),
                  ),
                  title: Text(category.name),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: Icon(Icons.edit, color: customGreen),
                        onPressed: () {
                          _showCategoryDialog(category: category);
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          showDialog(
                            context: context,
                            builder: (context) {
                              return AlertDialog(
                                title: Text('Delete Category'),
                                content: Text(
                                  'Are you sure you want to delete this category? Any tasks assigned to this category will be uncategorized.',
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                    child: Text('Cancel'),
                                  ),
                                  TextButton(
                                    onPressed: () async {
                                      await _firestoreDataSource
                                          .deleteCategory(category.id);
                                      Navigator.of(context).pop();
                                    },
                                    child: Text(
                                      'Delete',
                                      style: TextStyle(color: Colors.red),
                                    ),
                                  ),
                                ],
                              );
                            },
                          );
                        },
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showCategoryDialog();
        },
        child: Icon(Icons.add),
        backgroundColor: customGreen,
        tooltip: 'Add Category',
      ),
    );
  }
}
